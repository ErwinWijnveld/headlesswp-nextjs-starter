/* globals YoastACFAnalysisConfig */
module.exports = YoastACFAnalysisConfig;
